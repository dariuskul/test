import React from "react";

export default function test() {
  return (
    <div>
      <h1>Test page</h1>
    </div>
  );
}
