export * from "./RegisterPage";
