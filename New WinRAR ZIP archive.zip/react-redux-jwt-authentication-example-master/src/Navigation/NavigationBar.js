import React from "react";
import { Link, Route } from "react-router-dom";
import { userActions } from "../_actions";
import { connect } from "react-redux";
class NavigationBar extends React.Component {
  componentDidMount() {
    this.props.dispatch(userActions.getAll());
  }

  render() {
    const { user, users } = this.props;
    return (
      <nav class="navbar navbar-default">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="#">
              LeagueStatistics
            </a>
          </div>
          <ul class="nav navbar-nav">
            <li class="active">
              <a href="/">Home</a>
            </li>
            <li>
              <a href="/test">Test</a>
            </li>
            <li>
              <a href="#">Page 2</a>
            </li>
            <li>
              <a href="#">Page 3</a>
            </li>
          </ul>
        </div>
      </nav>
    );
  }
}

function mapStateToProps(state) {
  const { users, authentication } = state;
  const { user } = authentication;
  return {
    user,
    users
  };
}

const connectedNavigationBar = connect(mapStateToProps)(NavigationBar);
export { connectedNavigationBar as NavigationBar };

export default NavigationBar;
