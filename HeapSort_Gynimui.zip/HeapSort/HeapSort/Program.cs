﻿using HeapSort;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
namespace Sorts
{
    class Program
    {
        static int[] countArray = {10, 10000, 20000, 30000, 40000, 50000, 60000, 70000,80000 };
        const int DataLength = 8; //char[4] + float = 8
        static readonly Encoding Encoding = Encoding.UTF8;
        //For random generation
        static readonly byte[] UTF8 =
            Encoding.GetBytes("0123456789ABCDEFGHIJKLMNOPQRSTUVWXZabcdefghijklmnopqrstuvwzx");
        //Compares tuples
       private static readonly Comparer<(string, float)> Comparer = Comparer<(string word, float number)>.Create((a, b) => {
            var cmp = string.CompareOrdinal(a.Item1, b.Item1);
            return cmp != 0 ? cmp : a.Item2.CompareTo(b.Item2);
        });

        public static void Main(string[] args)
        {
            //// Testai
            //Console.WriteLine("------------------------------------------------------------------------------ RAM");
            ////for (int i = 0; i < countArray.Length; i++)
            ////{
            ////    SortRam(countArray[i]);
            ////}
            //Console.WriteLine("------------------------------------------------------------------------------ DISK");
            //for (int i = 0; i < countArray.Length; i++)
            //{
            //    SortFile(countArray[i]);
            //}
            Console.WriteLine("------------------------------------------------------------------------------ DISK");
            SortFile(countArray[0]);
            Console.WriteLine("------------------------------------------------------------------------------ RAM");
            SortRam(countArray[0]);

        }


        public static void SortRam(int count)
        {
            //for (int i = 0; i < 10; i++)
            //{
            //    var tree = new LightningTree<(string, float)>(Enumerable.Range(0, count).Select(x => ToTuple(GenerateData())), Comparer);
            //    time.Restart();
            //    var arr = tree.SortArr();
            //    time.Stop();
            //    av += time.Elapsed.Milliseconds;
            //}
            var tree = new LightningTree<(string, float)>(Enumerable.Range(0, count).Select(x => ToTuple(GenerateData())), Comparer);
            var arr = tree.SortArr();


            //Console.WriteLine("HeapSort in Ram time with " + count + " Elements: " + av/10.00 + " MiliSecconds");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i].ToString());
            }
        }

        public static void SortFile(int count)
        {
            WriteToFile(Enumerable.Range(0,count).Select(x=> GenerateData()),"Generated");
            var stream = new FileStream("Generated", FileMode.Open, FileAccess.Read); // Generating file with data
            var comparer = Comparer<int>.Create((a, b) => Comparer.Compare(ToTuple(ReadBytes(stream,a)), ToTuple(ReadBytes(stream,b)))); // Comparer which sorts indexes, which are asossiated with data
            //Stopwatch time = new Stopwatch();
            //double av = 0;
            //long res = 0;
            //for (int i = 0; i < 2; i++)
            //{
            //    var tree = new LightningTree<int>(Enumerable.Range(0, count).Select(i => i * DataLength), comparer);
            //    time.Restart();
            //    var arr = tree.SortArr();
            //    time.Stop();
            //    av += (time.Elapsed.Seconds);
            //}
            // Console.WriteLine("HeapSort in Disk with " + count + " Elements: " + (av/2.00) + " Seconds");
            var tree = new LightningTree<int>(Enumerable.Range(0, count).Select(i => i * DataLength), comparer);
            var arr = tree.SortArr();
            WriteToFile(arr.Select(i => ReadBytes(stream,i)),"Sorted");
            stream.Close();
            Console.WriteLine("BEFORE SORTED DISK");
            Console.WriteLine(string.Join("\n", DataToTuples(ReadFile("Generated"))));
            Console.WriteLine("AFTER SORTED DISK");
            Console.WriteLine(string.Join("\n", DataToTuples(ReadFile("Sorted"))));
        }


        public static void WriteToFile(IEnumerable<byte[]> data, string filename)
        {
            var writer = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.None);
            foreach (var item in data)
            {
                writer.Write(item, 0, item.Length);
            }
            writer.Close();
        }
        public static IEnumerable<byte[]> ReadFile(string filename)
        {
            var reader = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.None);
            for (var i = 0; i < reader.Length; i += DataLength)
            {
                var bytes = new byte[DataLength];
                reader.Read(bytes, 0, DataLength);
                yield return bytes;
            }
            reader.Close();
        }
        //Generates data to be sorted
        public static byte[] GenerateData()
        {
            var r = new Random();
            var bytes = new byte[DataLength];
            r.NextBytes(bytes);
            for (int i = 0; i < 4; i++)
            {
                bytes[i] = UTF8[r.Next(UTF8.Length)];
            }

            return bytes;
        }

        public static IEnumerable<(string, float)> DataToTuples(IEnumerable<byte[]> data) => data.Select(ToTuple);
        //Reads one tuple from file starting at specified index
        public static (string, float) ReadTuple(Stream stream, int index) => ToTuple(ReadBytes(stream, index));
        public static byte[] ReadBytes(Stream stream, int index)
        {
            var bytes = new byte[DataLength];
            stream.Seek(index, SeekOrigin.Begin);
            stream.Read(bytes, 0, DataLength);
            return bytes;
        }

        public static void WriteBytes(byte[] bytes, Stream stream, int index)
        {
            stream.Seek(index, SeekOrigin.Begin);
            stream.Write(bytes, 0, DataLength);
        }
        public static (string, float) ToTuple(byte[] bytes) =>
            (Encoding.GetString(bytes, 0, 4), BitConverter.ToSingle(bytes, 4));
        public static byte[] ToBytes(Tuple<string, float> tuple)
        {
            var bytes = new byte[DataLength];
            Buffer.BlockCopy(Encoding.GetBytes(tuple.Item1), 0, bytes, 0, 4);
            Buffer.BlockCopy(BitConverter.GetBytes(tuple.Item2), 0, bytes, 4, DataLength - 4);
            return bytes;
        }
    }
}