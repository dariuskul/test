﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace HeapSort
{
    public class LightningTree<T>
    {
        sealed class Node
        {
            internal T Data;
            internal Node Right, Left;
        }
        List<Node[]> Layers;
        Comparer<T> Comparer;
        int nodeIndex, layerIndex;
        public int Count { get; private set; }
        LightningTree(Comparer<T> comparer) => Comparer = comparer;
        public LightningTree(IEnumerable<T> items) : this(items, Comparer<T>.Default) { }
        public LightningTree(IEnumerable<T> items, Comparer<T> comparer) : this(comparer)
        {
            if (!(items is T[] arr)) arr = items.ToArray();
            if (arr.Length == 0) throw new Exception("Needs at least 1 element to initialize!");
            Count = arr.Length;
            layerIndex = (Layers = new List<Node[]>(new Node[Math.Max((int)(Math.Log(arr.Length) / Math.Log(2)),1)][])).Count - 1;
            Console.WriteLine(layerIndex);
            var leavesIndex = (int)Math.Pow(2, Layers.Count + 1) - 1;
            var lastLayer = new Node[leavesIndex + (nodeIndex = -(int)Math.Pow(2, Layers.Count)) + 1];
            nodeIndex += arr.Length;

            for (var i = lastLayer.Length - 1; i > -1; --i)
            {
                lastLayer[i] = --leavesIndex < arr.Length ? new Node { Data = arr[leavesIndex] } : null;
            }

            //for (int i = 0; i < lastLayer.Length-1; i++)
            //{
            //    if (lastLayer[i]!=null)
            //        Console.WriteLine(lastLayer[i].Data);
            //}
            for (var i = Layers.Count - 1; i > -1; --i)
            {
                Layers[i] = new Node[lastLayer.Length / 2];
                //Console.WriteLine(Layers[i][0].Data);
                var k = lastLayer.Length;
                for (var j = Layers[i].Length - 1; j > -1; --j)
                {
                    Layers[i][j] = new Node
                    {
                        Data = arr[--leavesIndex],
                        Right = lastLayer[--k],
                        Left = lastLayer[--k]
                    };
                }
                lastLayer = Layers[i];
            }

        }
        T Swap()
        {
            Count--;
            var node = Layers[layerIndex][nodeIndex / 2];
            //Console.WriteLine(node.Data);
            var left = nodeIndex % 2 == 0;
            var data = Layers[0][0].Data;
           // Console.WriteLine("Data"+data);
            Layers[0][0].Data = left ? node.Left.Data : node.Right.Data;
            if (left) node.Left = null;
            else node.Right = null;
            if (--nodeIndex == -1) nodeIndex = Layers[layerIndex--].Length - 1;
            return data;
        }
        public T[] SortArr()
        {
            var arr = new T[Count];
            var k = 0;
            for (var i = layerIndex; i > -1; --i)
            {

                for (int j = 0; j < Layers[i].Length; j++)
                {
                    Heapify(Layers[i][j]);
                }
            }
            while (Count != 1)
            {
                arr[k++] = Swap();
                Heapify(Layers[0][0]);
            }

            arr[k] = Layers[0][0].Data;
            return arr;
        }

        void Heapify(Node node)
        {
            while (true)
            {
                if (node.Left == null) return;
                var largest = node;
                if (Comparer.Compare(largest.Data, node.Left.Data) < 0) largest = node.Left;
                if (node.Right != null && Comparer.Compare(largest.Data, node.Right.Data) < 0) largest = node.Right;
                if (largest == node) return;
                var temp = node.Data;
                node.Data = largest.Data;
                largest.Data = temp;
                node = largest;
            }
        }
    }
}