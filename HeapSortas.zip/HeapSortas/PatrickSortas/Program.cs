﻿using HeapSort;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
namespace Sorts
{
    class Program
    {
        const int DataLength = 8; //char[4] + float = 8
        static readonly Encoding Encoding = Encoding.UTF8;
        //For random generation
        static readonly byte[] UTF8 =
            Encoding.GetBytes("0123456789ABCDEFGHIJKLMNOPQRSTUVWXZabcdefghijklmnopqrstuvwzx");
        //Compares tuples
        static readonly Comparer<Tuple<string, float>> Comparer = Comparer<Tuple<string, float>>.Create((a, b) => {
            var cmp = string.CompareOrdinal(a.Item1, b.Item1);
            return cmp != 0 ? cmp : a.Item2.CompareTo(b.Item2);
        });

        public static void Main(string[] args)
        {
            var count = 4;
            WriteToFile(GenerateData(count), "Generated");
            var stream = new FileStream("Generated", FileMode.Open, FileAccess.Read); // Generating file with data
            var comparer = Comparer<int>.Create((a, b) => Comparer.Compare(ReadTuple(stream, a), ReadTuple(stream, b))); // Comparer which sorts indexes, which are asossiated with data
            var tree = new LightningTree<int>(Enumerable.Range(0, count).Select(i => i * DataLength), comparer);
            var arr = tree.SortArr();
            //And write the tuples they correspond to in sorted order
            WriteToFile(arr.Select(i => ReadBytes(stream, i)), "Sorted"); // Writing sorted data into the file
            stream.Close();
            Console.WriteLine(string.Join("\n", DataToTuples(ReadFile("Sorted"))));

        }
        public static void WriteToFile(IEnumerable<byte[]> data, string filename)
        {
            var writer = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.None);
            foreach (var item in data)
            {
                writer.Write(item, 0, item.Length);
            }
            writer.Close();
        }
        public static IEnumerable<byte[]> ReadFile(string filename)
        {
            var reader = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.None);
            for (var i = 0; i < reader.Length; i += DataLength)
            {
                var bytes = new byte[DataLength];
                reader.Read(bytes, 0, DataLength);
                yield return bytes;
            }
            reader.Close();
        }
        //Generates data to be sorted
        public static IEnumerable<byte[]> GenerateData(int count)
        {
            var r = new Random();
            var number = new byte[DataLength - 4];
            for (var i = 0; i < count; ++i)
            {
                var bytes = new byte[DataLength];
                for (var j = 0; j < 4; ++j)
                    bytes[j] = UTF8[r.Next(UTF8.Length)];
                r.NextBytes(number);
                Buffer.BlockCopy(number, 0, bytes, 4, DataLength - 4);
                yield return bytes;
            }
        }
        public static IEnumerable<Tuple<string, float>> DataToTuples(IEnumerable<byte[]> data) => data.Select(ToTuple);
        //Reads one tuple from file starting at specified index
        public static Tuple<string, float> ReadTuple(Stream stream, int index) => ToTuple(ReadBytes(stream, index));
        public static byte[] ReadBytes(Stream stream, int index)
        {
            var bytes = new byte[DataLength];
            stream.Seek(index, SeekOrigin.Begin);
            stream.Read(bytes, 0, DataLength);
            return bytes;
        }

        public static void WriteBytes(byte[] bytes, Stream stream, int index)
        {
            stream.Seek(index, SeekOrigin.Begin);
            stream.Write(bytes, 0, DataLength);
        }
        public static Tuple<string, float> ToTuple(byte[] bytes) =>
            new Tuple<string, float>(Encoding.GetString(bytes,0,4), BitConverter.ToSingle(bytes, 4));
        public static byte[] ToBytes(Tuple<string, float> tuple)
        {
            var bytes = new byte[DataLength];
            Buffer.BlockCopy(Encoding.GetBytes(tuple.Item1), 0, bytes, 0, 4);
            Buffer.BlockCopy(BitConverter.GetBytes(tuple.Item2), 0, bytes, 4, DataLength - 4);
            return bytes;
        }
    }
}